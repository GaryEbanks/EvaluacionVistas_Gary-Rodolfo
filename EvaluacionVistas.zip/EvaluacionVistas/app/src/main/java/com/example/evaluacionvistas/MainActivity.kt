package com.example.evaluacionvistas

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnMultiplicar : Button = findViewById(R.id.btnMult)
        val numero : TextView = findViewById(R.id.etNumero)
        btnMultiplicar.setOnClickListener{
            var num = numero.toString().toInt()
            mostrarTabla(num)
        }
    }
}

class Table(val num: Int) {

    fun mostrar(): Int {
        return (num)
    }
}

private fun mostrarTabla(n: Int){
    val tabla = Table(n)
    val mostrarTabla = tabla.mostrar()
    val imagenTabla : ImageView = findViewById(R.id.ivTabla)
    val drawableResource = when (mostrarTabla) {
        1 -> R.drawable.tabla1
        2 -> R.drawable.tabla2
        3 -> R.drawable.tabla3
        4 -> R.drawable.tabla4
        5 -> R.drawable.tabla5
        6 -> R.drawable.tabla6
        7 -> R.drawable.tabla7
        8 -> R.drawable.tabla8
        9 -> R.drawable.tabla9
        10 -> R.drawable.tabla10
        11 -> R.drawable.tabla11
        12 -> R.drawable.tabla12
        else -> R.drawable.tabla1
    }
    imagenTabla.setImageResource(drawableResource)
}